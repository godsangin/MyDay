package com.msproject.myhome.mydays.main.event

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class EventActivity :AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
}