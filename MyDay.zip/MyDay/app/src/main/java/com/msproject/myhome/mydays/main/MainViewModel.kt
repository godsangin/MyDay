package com.msproject.myhome.mydays.main

class MainViewModel {

}